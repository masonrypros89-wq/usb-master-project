package com.example.usbmaster;

import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    private UsbStorageManager usbManager;
    private TextView statusText;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usbManager = new UsbStorageManager(this);
        statusText = findViewById(R.id.status_text);
        progressBar = findViewById(R.id.progress_bar);

        Button btnFill = findViewById(R.id.btn_fill);
        Button btnWipe = findViewById(R.id.btn_wipe);
        Button btnFat32 = findViewById(R.id.btn_format_fat32);
        Button btnExfat = findViewById(R.id.btn_format_exfat);

        btnFill.setOnClickListener(v -> handleFill());
        btnWipe.setOnClickListener(v -> handleWipe());
        btnFat32.setOnClickListener(v -> handleFormat(false));
        btnExfat.setOnClickListener(v -> handleFormat(true));
    }

    private void handleFill() {
        new Thread(() -> {
            runOnUiThread(() -> {
                progressBar.setVisibility(View.VISIBLE);
                statusText.setText("Filling storage...");
            });

            try {
                File usbDir = getExternalFilesDir(null); // Simplified for demo; real apps use StorageVolume
                if (usbDir != null) {
                    usbManager.fillStorage(usbDir);
                    runOnUiThread(() -> Toast.makeText(this, "Storage Filled", Toast.LENGTH_SHORT).show());
                }
            } catch (IOException e) {
                runOnUiThread(() -> Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show());
            } finally {
                runOnUiThread(() -> {
                    progressBar.setVisibility(View.GONE);
                    statusText.setText("USB Master - Idle");
                });
            }
        }).start();
    }

    private void handleWipe() {
        new Thread(() -> {
            runOnUiThread(() -> {
                progressBar.setVisibility(View.VISIBLE);
                statusText.setText("Wiping storage...");
            });

            File usbDir = getExternalFilesDir(null);
            if (usbDir != null) {
                usbManager.wipeStorage(usbDir);
                runOnUiThread(() -> Toast.makeText(this, "Storage Wiped", Toast.LENGTH_SHORT).show());
            }

            runOnUiThread(() -> {
                progressBar.setVisibility(View.GONE);
                statusText.setText("USB Master - Idle");
            });
        }).start();
    }

    private void handleFormat(boolean isExFat) {
        File usbDir = getExternalFilesDir(null);
        if (usbDir != null) {
            usbManager.requestFormat(usbDir, isExFat);
            Toast.makeText(this, "Format request sent for " + (isExFat ? "exFAT" : "FAT32"), Toast.LENGTH_SHORT).show();
        }
    }
}
