package com.example.usbmaster;

import android.content.Context;
import android.os.Environment;
import android.os.storage.StorageManager;
import android.os.storage.StorageVolume;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Random;

public class UsbStorageManager {
    private static final String TAG = "UsbStorageManager";
    private Context context;

    public UsbStorageManager(Context context) {
        this.context = context;
    }

    /**
     * Fills the remaining storage space with random data.
     */
    public void fillStorage(File directory) throws IOException {
        long freeSpace = directory.getFreeSpace();
        File fillFile = new File(directory, "fill_data.bin");
        byte[] buffer = new byte[1024 * 1024]; // 1MB buffer
        Random random = new Random();

        try (FileOutputStream fos = new FileOutputStream(fillFile)) {
            long written = 0;
            while (written < freeSpace) {
                random.nextBytes(buffer);
                int toWrite = (int) Math.min(buffer.length, freeSpace - written);
                fos.write(buffer, 0, toWrite);
                written += toWrite;
            }
        }
    }

    /**
     * Wipes the storage by deleting all files and directories.
     */
    public void wipeStorage(File directory) {
        if (directory.isDirectory()) {
            File[] files = directory.listFiles();
            if (files != null) {
                for (File file : files) {
                    recursiveDelete(file);
                }
            }
        }
    }

    private void recursiveDelete(File file) {
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) {
                for (File child : children) {
                    recursiveDelete(child);
                }
            }
        }
        file.delete();
    }

    /**
     * Note: Android does not allow direct low-level formatting (mkfs) of external drives 
     * from third-party apps due to security restrictions. 
     * Formatting is usually handled via the System Storage Settings or 
     * specialized Intent calls to the system's storage management.
     */
    public void requestFormat(File path, boolean isExFat) {
        // This is a conceptual trigger. In a real Android environment, 
        // you would use StorageManager or a System Intent to guide the user.
        Log.d(TAG, "Requesting format for: " + path.getAbsolutePath() + " to " + (isExFat ? "exFAT" : "FAT32"));
    }
}
